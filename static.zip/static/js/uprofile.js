function openNav() {
    document.getElementById("mySide-nav").style.width = "300px";
    document.getElementById("mainn").style.display = "block";
 }

 function closeNav() {
    document.getElementById("mySide-nav").style.width = "0";
    document.getElementById("mainn").style.display = "block";
 }